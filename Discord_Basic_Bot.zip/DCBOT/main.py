import os
import json
import re
import random
import asyncio
import discord
from discord.ext import commands, tasks
from discord import app_commands, ui, ButtonStyle, Embed, Interaction
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv
from discord.ui import View, Button

# ========== .env-file ==========
load_dotenv()
TOKEN = os.getenv("BOT_TOKEN") 

status_message = None
status_update_count = 0

# ========== ID's ==========
# for example BOTROLE_ID = 12345678901234567890
TEAMROLE_ID = 12345678901234567890 # -> Enter team role ID
BOT_UPDATE_ID = 12345678901234567890 # -> Enter Channel_ID where bot updates should be sent

# ========== Server-ID ==========
GUILD_ID = discord.Object(id=12345678901234567890) # -> Enter Guild_ID

# ========== enable Intents ==========
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True
intents.messages = True # -> Enable all intents in the developer portal

bot = commands.Bot(command_prefix="!", intents=intents)

# ========== Bot-Locker==========
def is_team_member(interaction: discord.Interaction) -> bool:
    member = interaction.user
    return any(role.id == TEAMROLE_ID for role in member.roles)

# ========== Rules ==========
RULES_TEXT = """ 
This are the rules 
"""
# -> For example

# ========== timeparser ==========
def parse_time(duration_str):
    """Converts e.g. '10s', '5m', '2h' to seconds"""
    match = re.match(r"^(\d+)([smhd])$", duration_str.lower())
    if not match:
        return None
    value, unit = int(match[1]), match[2]
    if unit == "s":
        return value
    elif unit == "m":
        return value * 60
    elif unit == "h":
        return value * 3600
    elif unit == "d":
        return value * 86400
    return None

# ========== on_ready ==========
@bot.event
async def on_ready():
    global status_message
    print(f"✅ Bot is online as {bot.user}")

    try:
        synced = await bot.tree.sync(guild=GUILD_ID)
        print(f"🔁 Slash-Commands synchronized: {len(synced)}")
    except Exception as e:
        print(f"❌ Sync error: {e}")

    await bot.wait_until_ready()

    channel = guild.get_channel(BOT_UPDATE_ID)
    if channel is None:
        print("❌ Channel not found.")
        return

    update_status.start()

# ========== Update, every 5min ============
start_time = datetime.now(timezone.utc)

@tasks.loop(minutes=5)
async def update_status():
    global status_message, status_update_count

    guild = bot.get_guild(12345678901234567890)
    if guild is None:
        print("❌ Guild not found.")
        return

    channel = guild.get_channel(BOT_UPDATE_ID)
    if channel is None:
        print("❌ Channel not found.")
        return

    status_update_count += 1

    # Update-Message
    latency = round(bot.latency * 1000)  
    uptime_delta = datetime.now(timezone.utc) - start_time

    days = uptime_delta.days
    hours, remainder = divmod(uptime_delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_str = f"{days}d {hours}h {minutes}m"

    content = (
        f"## ✅ __Bot is online:__\n"
        f"> ### 🛜 last Update: <t:{int(datetime.now(timezone.utc).timestamp())}:R>\n"
        f"> ### ⏱️ uptime: {uptime_str}\n"
        f"> ### 🔄 update's since start: {status_update_count}x\n"
        f"> ### 🔀 latency:```{latency}ms```"
    )

    try:
        if status_message is None:
            status_message = await channel.send(content)
        else:
            await status_message.edit(content=content)
    except discord.NotFound:
        status_message = await channel.send(content)
    except Exception as e:
        print(f"⚠️ Status-Update error: {e}")

# ========== e.g.-Cmd: /rules ==========
@bot.tree.command(name="rules", description="send a message with all rules", guild=GUILD_ID)
async def rules(interaction: discord.Interaction):
    if not is_team_member(interaction):
        await interaction.response.send_message("🚫 You do not have permission to use this command.", ephemeral=True)
        return    
    await interaction.response.send_message(f"### ✅ Here are the rules, {interaction.user.mention}:\n{RULES_TEXT}", ephemeral=False)

# ========== Botstart ==========
bot.run(TOKEN)        